const express=require('express')
const mysql=require('mysql')
const cors=require('cors')


const app=express()
app.use(cors());
app.use(express.json())
const db=mysql.createConnection({
    user:'root',
    host:'localhost',
    password:'',
    database:'userdb'
})


app.post('/sentdata',(req,res)=>{
    const id=req.body.id
    const pname=req.body.pname
    const price=req.body.price
    const quantity=req.body.quantity
    var qry="INSERT INTO user1(id,pname,price,quantity) VALUES(?,?,?,?)"
    db.query(qry,[id,pname,price,quantity],(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            console.log('inserted')}
    })

    db.query("ALTER TABLE sales ADD COLUMN "+pname+" INT",(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            console.log('ADDED COLUMN')}
    })
})

app.get('/receiveddata',(req,res)=>{
    
    var qry="SELECT * FROM user1"
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            res.send(result)
            console.log("extracted")
            }
    })
})

app.get('/chartsdata',(req,res)=>{          //for charts and profit
    
    var qry="SELECT * FROM sales"
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            res.send(result)
            console.log("extracted")
            }
    })
})
app.get('/totalprofit',(req,res)=>{          
    
    var qry="SELECT SUM(profit) FROM sales;"
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            res.send(result)
            console.log("extracted total profit")
            }
    })
})

app.get('/get_weekday_data',(req,res)=>{          //for charts
    
    var qry="SELECT AVG(SUNDAY),AVG(MONDAY), AVG(TUESDAY),AVG(WEDNESDAY),AVG(THURSDAY),AVG(FRIDAY),AVG(SATURDAY) FROM week_day_data"
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            res.send(result)
            console.log("extracted")
            }
    })
})

app.get('/top_product',(req,res)=>{          //for charts
    
    var qry="select id,pname,total_sale from user1 order by total_sale desc limit 3;"
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err)
        }       
        else{
            res.send(result)
            console.log("extracted")
            }
    })
})

app.post('/saleupdate',(req,res)=>{
    
    const id=req.body.id
    const pname=req.body.pname
    const salecount=req.body.salecount
    const profit=req.body.profit
    const date=req.body.day
    console.log(pname)
    var qry='INSERT INTO sales(date,'+pname+',profit) VALUES(CURDATE(),?,?) ON DUPLICATE KEY UPDATE  '+pname+'='+pname+'+'+salecount+' , profit=profit +'+profit+';'
    var qry2='update user1 set total_sale=(select sum('+pname+') from sales) where id='+id+';'
    //var qry3='INSERT INTO sales(profit) VALUES(?) ON DUPLICATE KEY UPDATE  profit=profit +'+profit+';'
    db.query(qry,[salecount,profit],(err,result)=>{
        if(err)
        {
            console.log(err)  
        }       
        else{
            console.log('inserted in sales')
        }
        
    })

    db.query(qry2,(err,result)=>{
        if(err)
        {
            console.log(err)  
        }       
        else{
            console.log('update total sum sale count')
        }
        
    })

    
    
})

app.post('/weekday_table_update',(req,res)=>{
    
    const id=req.body.id
    const pname=req.body.pname
    const salecount=req.body.salecount
    const date=req.body.day
    {
        var day
        if(date==0)
        day="sunday"
        else if(date==1)
        day="monday"
        else if(date==2)
        day="tuesday"
        else if(date==3)
        day="wednesday"
        else if(date==4)
        day="thursday"
        else if(date==5)
        day="friday"
        else if(date==6)
        day="saturday"
    }
    console.log(day)
    var qry='INSERT INTO week_day_data(dates,'+day+') VALUES(CURDATE(),?) ON DUPLICATE KEY UPDATE '+day+'='+day+'+'+salecount+';'
   
    db.query(qry,[salecount],(err,result)=>{
        if(err)
        {
            console.log(err)  
        }       
        else{
            console.log('inserted')
        }
        
    })

    
})

app.post('/delete_product',(req,res)=>{
    
    const id=req.body.id
    const pname=req.body.pname
    
    
    var qry='DELETE FROM USER1 WHERE ID='+id+';'
    var qry2="ALTER TABLE SALES DROP COLUMN "+pname+";"
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err)  
        }       
        else{
            console.log('deleted')
        }        
    })

    db.query(qry2,(err,result)=>{
        if(err)
        {
            console.log(err)  
        }       
        else{
            console.log('deleted')
        }        
    })

    
})

app.get('/',(req,res)=>{
    res.send('server running')
})

app.listen(3001,()=>{
    console.log('server running')
})