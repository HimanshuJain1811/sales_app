-- MariaDB dump 10.19  Distrib 10.4.19-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: userdb
-- ------------------------------------------------------
-- Server version	10.4.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `date` date NOT NULL,
  `cars` int(11) DEFAULT 0,
  `bedsheet` int(11) DEFAULT 0,
  `pepsi` int(11) DEFAULT 0,
  `profit` int(11) DEFAULT 0,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES ('2021-09-03',4,8,7,100),('2021-09-04',3,7,6,200),('2021-09-05',2,6,5,400),('2021-09-06',1,5,4,450),('2021-09-07',3,3,3,852),('2021-09-10',4,0,4,452),('2021-09-11',0,0,0,142),('2021-09-23',3,9,11,445),('2021-09-24',0,2,0,5858),('2021-09-27',3,0,0,2200);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user1`
--

DROP TABLE IF EXISTS `user1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(45) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_sale` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user1`
--

LOCK TABLES `user1` WRITE;
/*!40000 ALTER TABLE `user1` DISABLE KEYS */;
INSERT INTO `user1` VALUES (1,'cars',2000,5,23),(2,'bedsheet',200,5,40),(3,'pepsi',30,10,40);
/*!40000 ALTER TABLE `user1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `week_day_data`
--

DROP TABLE IF EXISTS `week_day_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `week_day_data` (
  `DATES` date NOT NULL,
  `MONDAY` int(11) DEFAULT NULL,
  `TUESDAY` int(11) DEFAULT NULL,
  `WEDNESDAY` int(11) DEFAULT NULL,
  `THURSDAY` int(11) DEFAULT NULL,
  `FRIDAY` int(11) DEFAULT NULL,
  `SATURDAY` int(11) DEFAULT NULL,
  `SUNDAY` int(11) DEFAULT NULL,
  PRIMARY KEY (`DATES`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week_day_data`
--

LOCK TABLES `week_day_data` WRITE;
/*!40000 ALTER TABLE `week_day_data` DISABLE KEYS */;
INSERT INTO `week_day_data` VALUES ('2021-09-04',NULL,NULL,NULL,NULL,NULL,6,NULL),('2021-09-05',NULL,NULL,NULL,NULL,NULL,NULL,4),('2021-09-06',10,NULL,NULL,NULL,NULL,NULL,NULL),('2021-09-07',NULL,9,NULL,NULL,NULL,NULL,NULL),('2021-09-08',NULL,NULL,8,NULL,NULL,NULL,NULL),('2021-09-09',NULL,NULL,NULL,6,NULL,NULL,NULL),('2021-09-10',NULL,NULL,NULL,NULL,10,NULL,NULL),('2021-09-11',NULL,NULL,NULL,NULL,NULL,8,NULL),('2021-09-23',NULL,NULL,NULL,34,NULL,NULL,NULL),('2021-09-24',NULL,NULL,NULL,NULL,2,NULL,NULL),('2021-09-27',4,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `week_day_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-28  0:19:53
