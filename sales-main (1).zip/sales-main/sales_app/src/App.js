import React,{useState} from 'react'

import Header from './components/header/Header'
import Body from './components/body/Body'



export default function App() {
    const [action, setaction] = useState(true)
    const [addproduct, setaddproduct] = useState(false)
    const [list, setlist] = useState(false)
    const [chart, setchart] = useState(false)
    const [addsales, setaddsales] = useState(false)
    const [profitview, setprofitview] = useState(false)

    const [productdata, setproductdata] = useState([{id:0,pname:'',price:0,quantity:0}])

    const handlechange_add=()=>{
        setaction(false)
        setaddproduct(true) 
        setlist(false) 
        setchart(false)  
        setprofitview(false)
        setaddsales(false)
        
    }

    const handlechange_action=()=>{
        setaction(true)
        setaddproduct(false)
        setlist(false) 
        setchart(false) 
        setprofitview(false)
        setaddsales(false)  
        
    }
    const handle_list=()=>{
        setaction(false)
        setaddproduct(false)
        setlist(true)
        setchart(false)
        setaddsales(false)
        setprofitview(false)
    }

    const handle_chart=()=>{
        setaction(false)
        setaddproduct(false)
        setlist(false)
        setprofitview(false)
        setchart(true)
        setaddsales(false)
    }
    const handle_addsales=()=>{
        setaction(false)
        setaddproduct(false)
        setlist(false)
        setchart(false)
        setprofitview(false)
        setaddsales(true)
    }
    const handle_profitview=()=>{
        setaction(false)
        setaddproduct(false)
        setlist(false)
        setchart(false)
        setaddsales(false)
        setprofitview(true)
    }
    
    
    return (
        <div>
           <Header 
           handleadd={handlechange_add} 
           handleaction={handlechange_action} 
           handlelist={handle_list} 
           handlechart={handle_chart} 
           handleprofitview={handle_profitview} 
            />
           
            <Body  
            action={action} 
            addproduct={addproduct} 
            list={list} chart={chart} 
            addsales={addsales} 
            profitview={profitview} 
            handleadd={handlechange_add} 
            handleaction={handlechange_action} 
            handlelist={handle_list} 
            handlechart={handle_chart} 
            handleaddsales={handle_addsales} 
            handleprofitview={handle_profitview} 
            data={productdata} 
            setdata={setproductdata} 
            sendproductdata={productdata} /> 
        </div>
    )
}
