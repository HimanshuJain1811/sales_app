import React,{useState} from 'react'
import styles from './product.module.css'
import axios from 'axios'


export default function Products(props) {
    const [newid, setnewid] = useState(0)
    const [newname, setnewname] = useState('')
    const [newprice, setnewprice] = useState(0)
    const [newquantity, setnewquantity] = useState(0)
    const [value, setvalue] = useState(null)
   

    const handlechangeid=(event)=>{
        setnewid(event.target.value)
        
    }
    const handlechangename=(event)=>{
        setnewname(event.target.value)
        
    }
    const handlechangeprice=(event)=>{
        setnewprice(event.target.value)
        
    }
    const handlechangequan=(event)=>{
        setnewquantity(event.target.value)
        
    }

    const submithandle=(event)=>{
        event.preventDefault()
        
        tobackend();

        setvalue("")

    };

    const tobackend=()=>{
        axios.post('http://localhost:3001/sentdata',{
            id:newid,
            pname:newname,
            price:newprice,
            quantity:newquantity
        }).then(()=>{
            console.log('success')
        })
    }

    

    
    return (
        <div>
            <form className={styles.form} onSubmit={submithandle} >
                <label className={styles.id}>ID</label>
                <input value={value} type='number' className={styles.idbox} onChange={handlechangeid} placeholder='here'/>
                <label className={styles.id}>Product Name</label>
                <input value={value} type='text' className={styles.idbox} onChange={handlechangename} placeholder='here'/>
                <label className={styles.id}>Price Per Item</label>
                <input value={value} type='number' className={styles.idbox} onChange={handlechangeprice} placeholder='here'/>
                <label className={styles.id}>Quantity</label>
                <input value={value} type='number' className={styles.idbox} onChange={handlechangequan} placeholder='here'/>
                <button type='submit' className={styles.submit}>Submit</button>
                {/* <button onClick={props.home} className={styles.back}>back</button> */}
            </form>
           
        </div>
    )
} 
