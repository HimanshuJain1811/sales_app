import axios from 'axios'
import React,{useState} from 'react'
import styles from './profit.module.css'
import moment from 'moment'

function Profit(props) {
    
   
     
    return (
        <div>      
            
            <div className={styles.box1}>
                <div className={styles.box2}>{moment(props.date).format('MMMM D, YYYY')}</div>
                <div className={styles.box3}>$ {props.profit}</div>

            </div>
            
            
            
        </div>
    )
}

export default Profit
