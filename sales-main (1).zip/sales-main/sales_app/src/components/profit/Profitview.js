import axios from 'axios';
import React, { Component } from 'react'
import styles from './profit.module.css'
import Profit from './Profit'

export default class  Profitview extends Component {
    
    constructor(){
        super();
        this.state={
            profit:[],
            totalprofit:0
            
        };
       
        
        
    }



    componentDidMount(){                 //get data from backend
        

        axios.get(`http://localhost:3001/chartsdata`)
          .then(res => {
            const data1 = res.data;
            this.setState({profit:data1})
            //console.log(this.state.profit)
          })

        axios.get(`http://localhost:3001/totalprofit`)
          .then(res => {
            const data2 = res.data;
            console.log(Object.values(data2[0]))
            this.setState({totalprofit:Object.values(data2[0])})
            //console.log(this.state.profit)
          })
    }

   

   
    
    

    

    render(){
        
    return (
        <div>
            
            <div className={styles.profitbox}>
                <div className={styles.ptag}>Profit</div>
                <div className={styles.value}>${this.state.totalprofit}</div>    
                    
                
            </div>
            

            {this.state.profit.map((item)=>(    //map the data 
                <Profit 
                key={item.date}
                date={item.date}
                profit={item.profit}
                
                
                />
            ))}
            
           
        </div>
    )
            }
}
