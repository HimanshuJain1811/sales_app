import React,{useState} from 'react'
import styles from './header.module.css'
import Navigation from './navigation/Navigation'
import icon from '../../assets/ham.png'
import Modal from 'react-modal'
import { v4 as uuidv4 } from 'uuid';

export default function Header(props) {
    const [sidetoggle, setsidetoggle] = useState(false)
    const [modalisopen, setmodalisopen] = useState(false)

    const [regusername, setregusername] = useState('')
    const [regpassword, setregpassword] = useState('')
    

    const close=()=>{
        setsidetoggle(false) 
    }
    const sidebar_toggle=()=>{
        setsidetoggle(true)
    }
   
    const submitregform=()=>{

        
        console.log(uuidv4())
        console.log(regusername)
        console.log(regpassword)
    }

    if(sidetoggle)
    {
        var nav=<Navigation close_sidebar={()=>close} toaddproduct={props.handleadd} tohome={props.handleaction} tolist={props.handlelist}/>
    }
    return (
        <div>
            <div className={styles.header}>
                <div className={styles.tag} onClick={props.handleaction}>SHOP</div>
                <img src={icon} alt='error in loading icon'  className={styles.navigation} onClick={sidebar_toggle}></img>    
                <button className={styles.modalopen}  onClick={()=>setmodalisopen(true)}>Register</button>
            </div>
            {nav}

            <Modal isOpen={modalisopen} onRequestClose={()=>setmodalisopen(false)}>
                <h1 className={styles.modalclose} onClick={()=>setmodalisopen(false)}>X</h1>

                <div className={styles.registration}>
                    <h2>Register account</h2>
                    <label>Username</label>
                    <input type="text" onChange={(event)=>setregusername(event.target.value)}></input>
                    <label>Password</label>
                    <input type="text" onChange={(event)=>setregpassword(event.target.value)}></input>
                    <button onClick={submitregform}>Submit</button>
                </div>
            </Modal>
            
        </div>
    )
}
