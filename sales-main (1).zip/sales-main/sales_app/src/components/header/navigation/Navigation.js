import React from 'react'
import styles from './navigation.module.css'


export default function Navigation (props) {

  

  
    return (
        <div>
            <div className={styles.sidebar}>
                <div className={styles.list}>
                    <div className={styles.item} onClick={props.tohome} >home</div>
                    <div className={styles.item} onClick={props.toaddproduct}>Add Product</div>
                    <div className={styles.item} onClick={props.tolist}>List Products</div>
                </div>
            </div>
            <div className={styles.wrapper} onClick={props.close_sidebar()}/>
        </div>
    )
}
