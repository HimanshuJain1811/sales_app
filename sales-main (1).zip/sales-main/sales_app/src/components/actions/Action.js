import React,{useState,useEffect} from 'react'
import styles from './action.module.css'
import axios from 'axios'
import Top_product from './Top_product'





export default class Action extends React.Component {

    constructor()
  {
    super();
    this.state={
      topproduct:[],
    };
  };

    componentDidMount()
    {
           axios.get(`http://localhost:3001/top_product`)
          .then(res => {
            const data1 = res.data;
            this.setState({topproduct:data1})
            console.log(this.state.topproduct)
          })

    }
     

    render(){
        return (
            <div>
                    
                    <div className={styles.topbox}>
                        <div className={styles.toptag}>TOP ITEMS</div>
                    {this.state.topproduct.map((data) => (
                    <Top_product 
                    pname={data.pname} />
                    ))}
    
                    </div>
                    
                    
    
    
                    <div className={styles.actionbox}>
                        <div className={styles.products} onClick={this.props.func} >Add Products</div>
                        <div className={styles.products} onClick={this.props.showlist} >List Products</div>
                        <div className={styles.products} onClick={this.props.showchart}>Charts</div>
                        <div className={styles.products} onClick={this.props.handleaddsales}>Sales</div>
                        <div className={styles.products} onClick={this.props.handleprofitview}>Profit</div>
                    </div>
                
                
            </div>
        )
    }
    
}
