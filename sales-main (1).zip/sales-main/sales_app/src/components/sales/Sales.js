import axios from 'axios';
import React, { Component } from 'react'
import Addsales from './Addsales'
import Profit from '../profit/Profit'

export default class  Sales extends Component {
    
    constructor(){
        super();
        this.state={
            data:[],
            profit:[],
            
        };
       
        
        
    }



    componentDidMount(){                 //get data from backend
        axios.get('http://localhost:3001/receiveddata')
        .then(response=>{
            const data=response.data
            this.setState({data})
        })

        axios.get(`http://localhost:3001/chartsdata`)
          .then(res => {
            const data1 = res.data;
            
            this.setState({profit:data1})
            //console.log(this.state.profit)
          })
    }

   

   
    
    

    

    render(){
        
    return (
        <div>
            
            {this.state.data.map((item)=>(    //map the data 
                <Addsales 
                key={item.id}
                id={item.id}
                pname={item.pname}
                price={item.price} 
                ref={this.submitref}
                
                />
            ))}

            {this.state.profit.map((item)=>(    //map the data 
                <Profit 
                key={item.date}
                date={item.date}
                profit={item.profit}
                
                
                />
            ))}
            
           
        </div>
    )
            }
}
