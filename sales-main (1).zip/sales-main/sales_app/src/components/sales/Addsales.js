import axios from 'axios'
import React,{useState} from 'react'
import styles from './sale.module.css'

function Addsales(props) {
    
    const [value, setvalue] = useState(0)     //sale value
    
    
    const handleadd=()=>{
        setvalue(prevvalue=>prevvalue+1)
        console.log(props.pname+"="+value)

    }
    const handlesubtract=()=>{
        setvalue(prevvalue=>prevvalue-1)
        console.log("count="+value);
    }

    var d=new Date()
    var day=d.getDay()
    
        
        
        const addsale=()=>{
            console.log(day)
            
            axios.post('http://localhost:3001/saleupdate',{
                id:props.id,
                pname:props.pname,
                salecount:value,
                profit:value*props.price,
                day:day
            }).then(()=>{
                console.log('success')
            })
            
            axios.post('http://localhost:3001/weekday_table_update',{
                id:props.id,
                pname:props.pname,
                salecount:value,
                day:day
            }).then(()=>{
                console.log('success')
            }) 


            setvalue(0)
  
        }
     

    
    
       
    

    return (
        <div>      
            
            <div className={styles.card}>
                <button className={styles.addbtn} onClick={handleadd} >+</button>
                
                <div>{props.pname}</div>
                <div>count={value}</div>
                <button className={styles.subbtn} onClick={handlesubtract} >-</button>
                
                
            </div> 
            <button type="submit" className={styles.submitbtn} onClick={addsale}>submit</button>
            
            
            
        </div>
    )
}

export default Addsales
