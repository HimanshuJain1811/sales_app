import React from 'react'
import Action from '../actions/Action'
import Products from '../products/Products'
import List from '../list/List'
import Chart from '../chart/Chart'
import Sales from '../sales/Sales'
import Profitview from '../profit/Profitview'




export default function Body(props) {
          
   

    if(props.action)
    {
        var act=<Action func={props.handleadd} showlist={props.handlelist} showchart={props.handlechart} handleaddsales={props.handleaddsales} handleprofitview={props.handleprofitview} setdata={props.setdata} sendpredata={props.sendproductdata} />
    }
    if(props.addproduct)
    {
        var add=<Products home={props.handleaction} setdata={props.setdata} sendpredata={props.sendproductdata}  />
    }
    if(props.list)
    {
        var lis=<List home={props.handleaction} listdata={props.data}/>
    }
    if(props.chart===true)
    {
        var chart=<Chart/>
    }
    if(props.addsales===true)
    {
        var sales=<Sales />
    }
    if(props.profitview===true)
    {
        var profitview=<Profitview />
    }
    return (
        <div >
            {act}
            {add}
            {lis}
            {chart}
            {sales}
            {profitview}
            
        </div>
    )
}
