import React, { Component } from 'react'
import Showlist from './Showlist'
import styles from './list.module.css'
import axios from 'axios'
import Modal from 'react-modal'
import Product from "../products/Products"

export default class List extends Component {
    constructor(){
        super();
        this.state={
            data1:[],
            isopen:false
        };
    }

    delete_product=(to_del_id)=>{
        let updated_data=this.state.data1.filter(data_ => data_.id !== to_del_id);

        this.setState({ data1: updated_data });
        
    }

    modaltoggle=()=>{
        this.setState({isopen:!this.state.isopen})
        console.log(this.state.isopen)
    }
    

    componentDidMount() {
        axios.get(`http://localhost:3001/receiveddata`)
          .then(res => {
            const data = res.data;
            this.setState({ data1:data });
            console.log(this.state.data1)
          }) 
      }

     
          
   
    
    
    
   render(){
    return (
        <div>
            <div className={styles.tag}>List
            {
            
            this.state.data1.map(({id,pname,price,quantity})=>(
                <Showlist 
                key={id}
                id={id}
                pname={pname}
                price={price}
                quantity={quantity}
                deletef={()=>this.delete_product(id)}
                 />
            ))}
            <button onClick={this.props.home} className={styles.back}>back</button>

            <button onClick={this.modaltoggle} className={styles.add_p}  >Add Product</button>
            
            </div> 
            <Modal className={styles.add_p_popup} 
            isOpen={this.state.isopen}
            onRequestClose={this.modaltoggle}>

                <button className={styles.close} onClick={this.modaltoggle}  >close</button>
                <Product/>
            </Modal>
            
        </div>
    )
    }
}
