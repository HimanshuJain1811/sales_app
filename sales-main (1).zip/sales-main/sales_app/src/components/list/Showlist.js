import React,{useState} from 'react'
import styles from './list.module.css'
import axios from 'axios'



export default function Showlist(props) {
    
    
    const closebox=()=>{

        props.deletef(props.id) //for temporary removal

        
        axios.post('http://localhost:3001/delete_product',{
                id:props.id,
                pname:props.pname,

            }).then(()=>{
                console.log('success')
            })          //to remove permenatly

        
           
    }

    return (
        <div>
            <div className={styles.finallist}>
                <div className={styles.close_btn} onClick={closebox}>X</div>
                <div className={styles.container}>
                <pre>ID:           {props.id}</pre>
                <pre>Product Name: {props.pname}</pre>
                <pre>Price:        {props.price}</pre>
                <pre>Quantity:     {props.quantity}</pre>
                
                </div>
            
            </div>
        </div>
    )
}
